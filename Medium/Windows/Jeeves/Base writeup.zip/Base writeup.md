# Machine Information

| **IP Address**       |     |
| -------------------- | --- |
| **Operating System** |     |
| **Hostname**         |     |
| **Domain**           |     |
| **Release Date**     |     |
| **Difficulty**       |     |

---
# Machine Description


---
# Exploitation Summary

The attack chain involved:


---
# Detailed Walkthrough

## Road to User flag

##### ***Phase 1:***

// descrizione
##### ***Phase 1:***

// descrizione

...

## Road to Root flag

##### ***Phase 1:***

// descrizione
##### ***Phase 1:***

// descrizione

...

---
## Key Vulnerabilities Exploited
